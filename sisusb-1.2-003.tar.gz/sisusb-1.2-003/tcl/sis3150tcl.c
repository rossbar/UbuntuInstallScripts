/***************************************************************************/
/*  Filename:  sis3150usb_vme.c                                            */
/*                                                                         */
/*  Funktion:   Tcl package to provide access to Vme.                      */
/*                                                                         */
/*  Autor:      R. Fox                                                     */
/* date:        09.06.2006  (coding begins)                                */
/*-------------------------------------------------------------------------*/
/*                                                                         */
/*  SIS  Struck Innovative Systeme GmbH                                    */
/*                                                                         */
/*  Harksheider Str. 102A                                                  */
/*  22399 Hamburg                                                          */
/*                                                                         */
/*  Tel. +49 (0)40 60 87 305 0                                             */
/*  Fax  +49 (0)40 60 87 305 20                                            */
/*                                                                         */
/*  http://www.struck.de                                                   */
/*                                                                         */
/*  � 2006                                                                 */
/*                                                                         */
/***************************************************************************/
static char* copyright=" � 2006 SIS Struck Innovated Systeme GmbH All rights reserved\n";

#include <tcl.h>
#include <sis3150usb_vme.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <sis3150usb_vme_calls.h>

/*
   Commands provided (all live in the sis3150 namespace)
      enumerate    - Returns a list of the USB boards found.  Each list element
                     is a sublist containing:
                     name    - Name of the usb device.
                     vendor  - SIS vendor code.
                     product - Should be 0x3150
                     serial  - Board serial number.
                     firmware- Firmware revision level.
      opensis name    - Opens the interface 'name' returning a handle to be used
                     for future operations.
      ldopen name
                   - Loads the cypress firmware into the devie and opens it.
                     If the firmware file name is given, that is the file that
                     is loaded, otherwise the standard SIS firmware is loaded.
      closesis handle - Closes the interface corresponding to the handle returned
                     by the open.
      regread handle number
                   - Returns the contents of register number for the interface
                     open on handle.
      regwrite handle number value
                   - Writes value to register number for the handle.
      vmereada32d32 handle address
      vmereada32d16 handle address
      vmereada32d8  handle address
      vmereada24d32 handle address
      vmereada24d16 handle address
      vmereada24d8  handle address
      vmereada16d32 handle address
      vmereada16d16 handle address
      vmereada16d8  handle address
                  - Performs the indicated vme read operation on the specified
                    address.

      vmewritea32d32 handle address  data
      vmewritea32d16 handle address  data
      vmewritea32d8  handle address  data
      vmewritea24d32 handle address  data
      vmewritea24d16 handle address  data
      vmewritea24d8  handle address  data
      vmewritea16d32 handle address  data
      vmewritea16d16 handle address  data
      vmewritea16d8  handle address  data
                  - Performs the indicateed vme write operations on the specified
                    address, transferring the appropriate number of bits of data.
      vmedmareada32d32 handle baseaddress count
      vmedmareada24d32 handle baseaddress count
                  - Performs a block transfer of the indicated number of 32 bit
                    longwords starting at baseaddress.  The results of the
                    read are returned as a list of hexadecimal values.
      vmedmawritea32d32 handle baseaddress data
      vmedmawritea24d32 handle baseaddress data
                  - Performs a block transfer write starting at baseaddress
                    data is a Tcl list of integers.  The size of this list
                    determines the transfer count.
*/

static char* version="1.0";

/*----------------------- Helper functions ----------------------------*/

/*  Helper for enumerate: append device information to an existing list. 
    result - output list
    device - Info about a device.
*/
static void
 appendDevice(Tcl_Interp* pInterp, 
	      Tcl_Obj* result, struct SIS3150USB_Device_Struct* device)
{
  Tcl_Obj* element = Tcl_NewListObj(0, NULL);
  Tcl_Obj* name = Tcl_NewStringObj(device->cDName, -1);
  Tcl_ListObjAppendElement(pInterp, element, name);
  Tcl_Obj* value = Tcl_NewIntObj(device->idVendor);
  Tcl_ListObjAppendElement(pInterp, element, value);
  value          = Tcl_NewIntObj(device->idProduct);
  Tcl_ListObjAppendElement(pInterp, element, value);
  value          = Tcl_NewIntObj(device->idSerNo);
  Tcl_ListObjAppendElement(pInterp, element, value);
  value          = Tcl_NewIntObj(device->idFirmwareVersion);
  Tcl_ListObjAppendElement(pInterp, element, value);
  Tcl_ListObjAppendElement(pInterp, result, element);

}

/* 
   Helper function for the dma reads: Marshall a block of longwords into
   a list.
  
*/
static Tcl_Obj*
longsToList(u_int32_t* data, size_t count)
{
  Tcl_Obj*  list;
  Tcl_Obj*  value;
  int       i;
  int       status;

  list = Tcl_NewListObj(0, NULL); /* Make the empty list object. */

  for (i = 0; i < count; i++) {
    value = Tcl_NewLongObj(*data);
    status = Tcl_ListObjAppendElement(NULL, list, value);
    data++;
  }
  return list;
}
/*  
  Helper function that marshalls the elements of a list of integers
  into a buffer of 32 bit longs.  The buffer is heap allocated and,
  if TCL_OK is returned, must be deallocated by the caller.
*/
static int
listToLongs(Tcl_Interp* pInterp,  Tcl_Obj* list,
	    u_int32_t** ppBuffer, size_t*  pCount)
{
  int           status;
  int           count;
  int           index;
  u_int32_t*    pBuffer = 0;
  Tcl_Obj*      element;


  status = Tcl_ListObjLength(pInterp, list, &count);
  if (status != TCL_OK) goto error;

  /* Allocate the buffer of longs to hold the result: */

  pBuffer = (u_int32_t*)Tcl_Alloc(count*sizeof(u_int32_t));
  if(!pBuffer) {
    status = TCL_ERROR;
    goto error;
  }

  /* Extract the data into the buffer:   */

  for (index = 0; index < count; index++) {
    status = Tcl_ListObjIndex(pInterp, list, index, &element);
    if (status != TCL_OK) {
      goto error;
    }
    status = Tcl_GetLongFromObj(pInterp, element, (long*)(&(pBuffer[index])));
    if (status != TCL_OK) {
      goto error;
    }
  }
  /* If we got this far we are successful: */


  *ppBuffer = pBuffer;
  *pCount   = count;
  return TCL_OK;

  /* Common error handling.. yeah I know GOTO is considered harmful, but
     so is duplication of common code... we just get sent here on
     TCL_ERROR returns from Tcl API functions.
  */
 error:
  if (pBuffer) {
    Tcl_Free((char*)pBuffer);
  }
  return status;
}

/* ------------------------- administrative command implementations --------*/

/*   
    Implement the enumerate command
*/


static int 
enumerate(ClientData cd, Tcl_Interp* pInterp, 
	  int objc, Tcl_Obj* CONST objv[])
{
  struct SIS3150USB_Device_Struct* devices = NULL;
  unsigned int                     numDevices;
  int                              i;
  Tcl_Obj*  result;
  if (objc != 1) {
    result = Tcl_NewStringObj("Too many command arguments for sis3150::enumerate", -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  FindAll_SIS3150USB_Devices(NULL,
			     &numDevices,
			     0);

  /* Short circuit return if there are no devices: */

  if (numDevices == 0) {
    result = Tcl_NewListObj(0, NULL);
    Tcl_SetObjResult(pInterp, result);
    return TCL_OK;
  }

  devices = (struct SIS3150USB_Device_Struct*)
    Tcl_Alloc(numDevices*sizeof(struct SIS3150USB_Device_Struct));
  
  FindAll_SIS3150USB_Devices(devices,
			     &numDevices,
			     numDevices);
  result = Tcl_NewListObj(0, NULL);
  for (i = 0; i < numDevices; i++) {
    appendDevice(pInterp, result, &(devices[i]));
  }

  /* return the result */

  Tcl_SetObjResult(pInterp, result);
  Tcl_Free((char*)devices);
  return TCL_OK;
}


/*
   Open the interface:
      open  interfaceName
   Returns an interface handle.  The interface handle is just the
   integerized equivalent of the handle from the underlying function.
   If Tcl_Error, the reason for the error is in the result.
  
*/
static int
opensis(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj*   result;
  int        status;
  HANDLE     handle;

  /*  Must have exactly one argument; the name of the device. */

  objc--;
  if (objc != 1) {
    result = Tcl_NewStringObj("sis3150::open should only have a name parameter",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  status = Sis3150usb_OpenDriver(Tcl_GetString(objv[1]), &handle);

  /* On failure, status is the negative of an errno: */

  if(status != 0) {
    result = Tcl_NewStringObj(strerror(-status),-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  /* Return the handle as an int object.   */

  result = Tcl_NewLongObj((long)handle);
  Tcl_SetObjResult(pInterp, result);
  return TCL_OK;

}

/*
  Open a device and load it with the firmware.  Firmware file is
  fixed and unalterable.

 */
static int
ldopen(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  int      status;
  HANDLE   handle;

  /* Must be exactly one parameter, the name of the device.   */
  /*  Must have exactly one argument; the name of the device. */

  objc--;
  if (objc != 1) {
    result = Tcl_NewStringObj("sis3150::ldopen should only have a name parameter",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  status = Sis3150usb_OpenDriver_And_Download_FX2_Setup(Tcl_GetString(objv[1]), 
							&handle);

  /* On failure, status is the negative of an errno: */

  if(status != 0) {
    result = Tcl_NewStringObj(strerror(-status),-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  /* Return the handle as an int object.   */

  result = Tcl_NewLongObj((long)handle);
  Tcl_SetObjResult(pInterp, result);
  return TCL_OK;

}
/*
   Close and sis device already opened either with open or ldopen.
   There should be a single parameter, the handle returned from the open/ldopen
   command.
*/
static int
closesis(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  int      status;
  /*  Must have exactly one argument; the name of the device. */

  objc--;
  if (objc != 1) {
    result = Tcl_NewStringObj("sis3150::close should only have a handle parameter",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  /* Extract the handle from the object parameter: */
  
  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)(&handle));
  if (status != TCL_OK) {
    return status;
  }

  /* Now we can close..   */

  status = Sis3150usb_CloseDriver(handle);
  if (status != 0) {
    result = Tcl_NewStringObj(strerror(-status), -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  return TCL_OK;
}

/*--------------------------- Register access commands -----------------*/
 
/* Read a register  need a handle, and a register number.
   On success the value read is the result.
*/
static int
regread(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj*   result;
  HANDLE     handle;
  int        registerNumber;
  ULONG      registerValue;
  int        status;

  objc--;

  /*  Need exactly 2 arguments */

  if (objc != 2) {
    result = Tcl_NewStringObj("regread - needs handle register", -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  /* Pull out the handle and the register number: */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)(&handle));
  if (status != TCL_OK) return status;
  status = Tcl_GetIntFromObj(pInterp,  objv[2], &registerNumber);
  if (status != TCL_OK) return status;

  /* Got them now read the register.   */

  status = sis3150Usb_Register_Single_Read(handle, registerNumber, &registerValue);
  if (status != 0) {
    char message[100];
    sprintf(message, "regread bad status 0x%x", status);
    result = Tcl_NewStringObj(message, -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  result = Tcl_NewLongObj(registerValue);
  Tcl_SetObjResult(pInterp, result);
  return TCL_OK;

}
/*
    Write a register, need a handle, a register number and data.
    On success, nothing is returned.
*/
static int
regwrite(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj*   result;
  HANDLE     handle;
  int        registerNumber;
  long       registerValue;
  int        status;

  objc--;

  /*  Need exactly 2 arguments */

  if (objc != 3) {
    result = Tcl_NewStringObj("regwrite - needs handle register value", -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  /* Pull out the handle and the register number: */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)(&handle));
  if (status != TCL_OK) return status;
  status = Tcl_GetIntFromObj(pInterp,  objv[2], &registerNumber);
  if (status != TCL_OK) return status;
  status = Tcl_GetLongFromObj(pInterp, objv[3], &registerValue);

  /* Got them now read the register.   */

  status = sis3150Usb_Register_Single_Write(handle, registerNumber, registerValue);
  if (status != 0) {
    char message[100];
    sprintf(message, "regwrite bad status 0x%x", status);
    result = Tcl_NewStringObj(message, -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  return TCL_OK;  
}

/*------------------------ Single shot vme a32 access ----------------------*/

/* read 32 bits wide from a32 space. */

static int
vmereada32d32(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  ULONG    value;
  int      status;

  /* Need 2 parameters: handle and address */

  objc--;
  if (objc != 2) {
    result = Tcl_NewStringObj("vmereada32d32 handle address",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }

  /* do the operation: */

  status = vme_A32D32_read(handle, address, (u_int32_t*)&value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmereada32d32 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }
  result = Tcl_NewLongObj(value);
  Tcl_SetObjResult(pInterp, result);
  return TCL_OK;
  
}
/* write 32 bits wide to a32 space */

static int
vmewritea32d32(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  ULONG    value;
  int      status;

  /* Need 3 parameters: handle address value */

  objc--;
  if (objc != 3) {
    result = Tcl_NewStringObj("vmewritea32d32 handle address value",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[3], (long*)&value);
  if (status != TCL_OK) {
    return status;
  }



  /* do the operation: */

  status = vme_A32D32_write(handle, address, value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmewritea32d32 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }

  return TCL_OK;
}
/*
  Implement vmereada32d16 - 16 bit read from a32 space.

 */
static int
vmereada32d16(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  u_int16_t value;
  int      status;

  /* Need 2 parameters: handle and address */

  objc--;
  if (objc != 2) {
    result = Tcl_NewStringObj("vmereada32d16 handle address",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }

  /* do the operation: */

  status = vme_A32D16_read(handle, address, &value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmereada32d16 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }
  result = Tcl_NewIntObj(value);
  Tcl_SetObjResult(pInterp, result);
  return TCL_OK;
  
}
/* 
   Implement vmewritea32d16 - 16 bit write to a32 space: 
*/

static vmewritea32d16(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  ULONG    value;
  int      status;

  /* Need 3 parameters: handle address value */

  objc--;
  if (objc != 3) {
    result = Tcl_NewStringObj("vmewritea32d16 handle address value",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[3], (long*)&value);
  if (status != TCL_OK) {
    return status;
  }


  /* do the operation: */

  status = vme_A32D16_write(handle, address, value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmewritea32d16 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }

  return TCL_OK;
}

/* 
   vmereada32d8 - write 8 bits wide to a32 space.  This is untested
   since I don't have a d8 capable a32 memory board... but most likely
   works..since there's a lot of cut and paste from the other vmereada32
   code
*/
static int
vmereada32d8(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  u_int8_t value;
  int      status;

  /* Need 2 parameters: handle and address */

  objc--;
  if (objc != 2) {
    result = Tcl_NewStringObj("vmereada32d8 handle address",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }

  /* do the operation: */

  status = vme_A32D8_read(handle, address, &value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmereada32d8 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }
  result = Tcl_NewIntObj(value);
  Tcl_SetObjResult(pInterp, result);
  return TCL_OK;
  
}
/*
  vmewritea32d8 - write 8 bits wide to a32 space.. this is also untested
  since I don't have a d8 capable a32 memory board... but most likely
  works... see above.
*/
static int
vmewritea32d8(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  ULONG    value;
  int      status;

  /* Need 3 parameters: handle address value */

  objc--;
  if (objc != 3) {
    result = Tcl_NewStringObj("vmewritea32d8 handle address value",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[3], (long*)&value);
  if (status != TCL_OK) {
    return status;
  }


  /* do the operation: */

  status = vme_A32D8_write(handle, address, value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmewritea32d8 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }

  return TCL_OK;
}

/*----------------------- Single shot a24 access ---------------------*/

/* read 32 bits wide from a24 space. */

static int
vmereada24d32(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  ULONG    value;
  int      status;

  /* Need 2 parameters: handle and address */

  objc--;
  if (objc != 2) {
    result = Tcl_NewStringObj("vmereada24d32 handle address",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }

  /* do the operation: */

  status = vme_A24D32_read(handle, address, (u_int32_t*)&value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmereada24d32 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }
  result = Tcl_NewLongObj(value);
  Tcl_SetObjResult(pInterp, result);
  return TCL_OK;
  
}
/* write 32 bits wide to a24 space */

static int
vmewritea24d32(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  ULONG    value;
  int      status;

  /* Need 3 parameters: handle address value */

  objc--;
  if (objc != 3) {
    result = Tcl_NewStringObj("vmewritea24d32 handle address value",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[3], (long*)&value);
  if (status != TCL_OK) {
    return status;
  }



  /* do the operation: */

  status = vme_A24D32_write(handle, address, value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmewritea24d32 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }

  return TCL_OK;
}
/*
  Implement vmereada24d16 - 16 bit read from a24 space.

 */
static int
vmereada24d16(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  u_int16_t value;
  int      status;

  /* Need 2 parameters: handle and address */

  objc--;
  if (objc != 2) {
    result = Tcl_NewStringObj("vmereada24d16 handle address",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }

  /* do the operation: */

  status = vme_A24D16_read(handle, address, &value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmereada24d16 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }
  result = Tcl_NewIntObj(value);
  Tcl_SetObjResult(pInterp, result);
  return TCL_OK;
  
}
/* 
   Implement vmewritea24d16 - 16 bit write to a24 space: 
*/

static vmewritea24d16(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  ULONG    value;
  int      status;

  /* Need 3 parameters: handle address value */

  objc--;
  if (objc != 3) {
    result = Tcl_NewStringObj("vmewritea24d16 handle address value",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[3], (long*)&value);
  if (status != TCL_OK) {
    return status;
  }


  /* do the operation: */

  status = vme_A24D16_write(handle, address, value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmewritea24d16 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }

  return TCL_OK;
}

/* 
   vmereada24d8 - write 8 bits wide to a24 space.

*/
static int
vmereada24d8(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  u_int8_t value;
  int      status;

  /* Need 2 parameters: handle and address */

  objc--;
  if (objc != 2) {
    result = Tcl_NewStringObj("vmereada24d8 handle address",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }

  /* do the operation: */

  status = vme_A24D8_read(handle, address, &value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmereada24d8 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }
  result = Tcl_NewIntObj(value);
  Tcl_SetObjResult(pInterp, result);
  return TCL_OK;
  
}
/*
  vmewritea24d8 - write 8 bits wide to a24 space.

*/
static int
vmewritea24d8(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  ULONG    value;
  int      status;

  /* Need 3 parameters: handle address value */

  objc--;
  if (objc != 3) {
    result = Tcl_NewStringObj("vmewritea24d8 handle address value",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[3], (long*)&value);
  if (status != TCL_OK) {
    return status;
  }


  /* do the operation: */

  status = vme_A24D8_write(handle, address, value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmewritea24d8 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }

  return TCL_OK;
}


/*------------------------------- a16 single shot vme access ---------------------*/
/*     NOTE these commands are untested as I don't have an a16 memory board I  
       can test them against.  However since they are essentially cut and
       pastes of the a24 commands which are completely tested, they should
       work theoreticaly... too bad I was originally an experimentalist.
*/
/* read 32 bits wide from a16 space. */

static int
vmereada16d32(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  ULONG    value;
  int      status;

  /* Need 2 parameters: handle and address */

  objc--;
  if (objc != 2) {
    result = Tcl_NewStringObj("vmereada16d32 handle address",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }

  /* do the operation: */

  status = vme_A16D32_read(handle, address, (u_int32_t*)&value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmereada16d32 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }
  result = Tcl_NewLongObj(value);
  Tcl_SetObjResult(pInterp, result);
  return TCL_OK;
  
}
/* write 32 bits wide to a16 space */

static int
vmewritea16d32(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  ULONG    value;
  int      status;

  /* Need 3 parameters: handle address value */

  objc--;
  if (objc != 3) {
    result = Tcl_NewStringObj("vmewritea16d32 handle address value",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[3], (long*)&value);
  if (status != TCL_OK) {
    return status;
  }



  /* do the operation: */

  status = vme_A16D32_write(handle, address, value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmewritea16d32 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }

  return TCL_OK;
}
/*
  Implement vmereada16d16 - 16 bit read from a16 space.

 */
static int
vmereada16d16(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  u_int16_t value;
  int      status;

  /* Need 2 parameters: handle and address */

  objc--;
  if (objc != 2) {
    result = Tcl_NewStringObj("vmereada16d16 handle address",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }

  /* do the operation: */

  status = vme_A16D16_read(handle, address, &value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmereada16d16 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }
  result = Tcl_NewIntObj(value);
  Tcl_SetObjResult(pInterp, result);
  return TCL_OK;
  
}
/* 
   Implement vmewritea16d16 - 16 bit write to a16 space: 
*/

static vmewritea16d16(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  ULONG    value;
  int      status;

  /* Need 3 parameters: handle address value */

  objc--;
  if (objc != 3) {
    result = Tcl_NewStringObj("vmewritea16d16 handle address value",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[3], (long*)&value);
  if (status != TCL_OK) {
    return status;
  }


  /* do the operation: */

  status = vme_A16D16_write(handle, address, value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmewritea16d16 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }

  return TCL_OK;
}

/* 
   vmereada16d8 - write 8 bits wide to a16 space.

*/
static int
vmereada16d8(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  u_int8_t value;
  int      status;

  /* Need 2 parameters: handle and address */

  objc--;
  if (objc != 2) {
    result = Tcl_NewStringObj("vmereada16d8 handle address",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }

  /* do the operation: */

  status = vme_A16D8_read(handle, address, &value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmereada16d8 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }
  result = Tcl_NewIntObj(value);
  Tcl_SetObjResult(pInterp, result);
  return TCL_OK;
  
}
/*
  vmewritea16d8 - write 8 bits wide to a16 space.

*/
static int
vmewritea16d8(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj* result;
  HANDLE   handle;
  ULONG    address;
  ULONG    value;
  int      status;

  /* Need 3 parameters: handle address value */

  objc--;
  if (objc != 3) {
    result = Tcl_NewStringObj("vmewritea16d8 handle address value",-1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters. */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)&handle);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)&address);
  if (status != TCL_OK) {
    return status;
  }
  status = Tcl_GetLongFromObj(pInterp, objv[3], (long*)&value);
  if (status != TCL_OK) {
    return status;
  }


  /* do the operation: */

  status = vme_A16D8_write(handle, address, value);
  if (status != 0) {
    char message[100];
    sprintf(message, "vmewritea16d8 failed 0x%x\n", status);
    result = Tcl_NewStringObj(message, -1);
    return TCL_ERROR;
  }

  return TCL_OK;
}

/*---------------------------- DMA transfer functions --------------------*/

/* Dma read from a32 space. (D32)   */

static int
vmedmareada32d32(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj*    result;
  HANDLE      handle;
  u_int32_t   base;
  u_int32_t   count;
  u_int32_t*  pBuffer;
  int         status;
  int         transferCount;

  /* vmedmareada32d32 handle base count    - validate the parameter count: */

  objc--;
  if (objc != 3) {
    result = Tcl_NewStringObj("vmedmareada32d32 handle base count", -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters:   */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)(&handle));
  if(status != TCL_OK)  return status;

  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)(&base));
  if(status != TCL_OK) return status;

  status = Tcl_GetLongFromObj(pInterp, objv[3], (long*)(&count));

  /* Now allocate the buffer for the read..    */

  pBuffer = (u_int32_t*)Tcl_Alloc(count*sizeof(u_int32_t*));
  if (!pBuffer) {
    int error = Tcl_GetErrno();
    result = Tcl_NewStringObj(Tcl_ErrnoMsg(error), -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  /* Do the read   */

  status = vme_A32DMA_D32_read(handle, base, pBuffer, count, &transferCount);
  if (status != 0) {
    char msg[100];
    Tcl_Free((char*)pBuffer);
    sprintf(msg, "vmedmareada32d32 failed : 0x%x", status);
    result = Tcl_NewStringObj(msg, -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  /* Marshall the results into a list and let the user know we succeeded! */

  result = longsToList(pBuffer, transferCount);
  Tcl_SetObjResult(pInterp, result);
  Tcl_Free((char*)pBuffer);

  return TCL_OK;
  
}

/* DMA write to a32 space (D32)          */

static int
vmedmawritea32d32(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj*    result;
  HANDLE      handle;
  u_int32_t   base;
  u_int32_t   count;
  u_int32_t*  pBuffer;
  int         status;
  size_t      transferCount;

  /*  vmedmawritea32d32  handle base count list-of-data  - Check parameter count */

  objc--;
  if(objc != 3) {
    result = Tcl_NewStringObj("vmedmawritea32d32 handle base list-of-data", 
			      -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  /* Now pull out the parameters (including data marshalled into a buffer */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)(&handle));
  if (status != TCL_OK) return status;

  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)(&base));
  if (status != TCL_OK) return status;

  status = listToLongs(pInterp, objv[3], &pBuffer, &count);
  if (status != TCL_OK) return status;

  /* Now we can pop off the dma */

  status = vme_A32DMA_D32_write(handle, base, pBuffer, count, &transferCount);
  Tcl_Free((char*)pBuffer);	/* done with this regardless of status. */

  if(status != 0) {
    char msg[100];
    sprintf(msg, "vmedmawritea32d32 transfer failed: 0x%x\n", status);
    result = Tcl_NewStringObj(msg, -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  return TCL_OK;


}

/* Dma read from a24 space. (D32)   */

static int
vmedmareada24d32(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj*    result;
  HANDLE      handle;
  u_int32_t   base;
  u_int32_t   count;
  u_int32_t*  pBuffer;
  int         status;
  int         transferCount;

  /* vmedmareada24d32 handle base count    - validate the parameter count: */

  objc--;
  if (objc != 3) {
    result = Tcl_NewStringObj("vmedmareada24d32 handle base count", -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  /* Extract the parameters:   */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)(&handle));
  if(status != TCL_OK)  return status;

  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)(&base));
  if(status != TCL_OK) return status;

  status = Tcl_GetLongFromObj(pInterp, objv[3], (long*)(&count));

  /* Now allocate the buffer for the read..    */

  pBuffer = (u_int32_t*)Tcl_Alloc(count*sizeof(u_int32_t*));
  if (!pBuffer) {
    int error = Tcl_GetErrno();
    result = Tcl_NewStringObj(Tcl_ErrnoMsg(error), -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  /* Do the read   */

  status = vme_A24DMA_D32_read(handle, base, pBuffer, count, &transferCount);
  if (status != 0) {
    char msg[100];
    Tcl_Free((char*)pBuffer);
    sprintf(msg, "vmedmareada24d32 failed : 0x%x", status);
    result = Tcl_NewStringObj(msg, -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  /* Marshall the results into a list and let the user know we succeeded! */

  result = longsToList(pBuffer, transferCount);
  Tcl_SetObjResult(pInterp, result);
  Tcl_Free((char*)pBuffer);

  return TCL_OK;
  
}

/* DMA write to a24 space (D32)          */

static int
vmedmawritea24d32(ClientData cd, Tcl_Interp* pInterp, int objc, Tcl_Obj* CONST objv[])
{
  Tcl_Obj*    result;
  HANDLE      handle;
  u_int32_t   base;
  u_int32_t   count;
  u_int32_t*  pBuffer;
  int         status;
  size_t      transferCount;

  /*  vmedmawritea24d32  handle base count list-of-data  - Check parameter count */

  objc--;
  if(objc != 3) {
    result = Tcl_NewStringObj("vmedmawritea24d32 handle base list-of-data", 
			      -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }
  /* Now pull out the parameters (including data marshalled into a buffer */

  status = Tcl_GetLongFromObj(pInterp, objv[1], (long*)(&handle));
  if (status != TCL_OK) return status;

  status = Tcl_GetLongFromObj(pInterp, objv[2], (long*)(&base));
  if (status != TCL_OK) return status;

  status = listToLongs(pInterp, objv[3], &pBuffer, &count);
  if (status != TCL_OK) return status;

  /* Now we can pop off the dma */

  status = vme_A24DMA_D32_write(handle, base, pBuffer, count, &transferCount);
  Tcl_Free((char*)pBuffer);	/* done with this regardless of status. */

  if(status != 0) {
    char msg[100];
    sprintf(msg, "vmedmawritea24d32 transfer failed: 0x%x\n", status);
    result = Tcl_NewStringObj(msg, -1);
    Tcl_SetObjResult(pInterp, result);
    return TCL_ERROR;
  }

  return TCL_OK;


}

/*----------------------------- Package initialization --------------------*/

/*
    Register the package and its commands with the interpreter.
*/
int Sis_Init(Tcl_Interp* pInterp)
{
  int status;

  /* Register the package:                                           */

  status = Tcl_PkgProvide(pInterp, "sis3150", version);
  if (status != TCL_OK) {
    return status;
  }

  /* Create the sis3150 namespace so that our commands can be defined */
  /* inside of it.                                                    */

  status = Tcl_GlobalEval(pInterp, "namespace eval sis3150 {}");
  if (status != TCL_OK) {
    return status;
  }


  /*  Now register our commands:   */

  /* Administrative commands */
  
  Tcl_CreateObjCommand(pInterp, "sis3150::enumerate", enumerate, NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::opensis",      opensis,   NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::ldopen",    ldopen,    NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::closesis",     closesis,  NULL, NULL);

  /* Register access  */

  Tcl_CreateObjCommand(pInterp, "sis3150::regread",   regread,   NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::regwrite",  regwrite,  NULL, NULL);

  /* Single shot a32 access */

  Tcl_CreateObjCommand(pInterp, "sis3150::vmereada32d32", vmereada32d32, NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmewritea32d32", vmewritea32d32, 
		       NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmereada32d16", vmereada32d16, NULL,NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmewritea32d16", vmewritea32d16, NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmereada32d8", vmereada32d8, NULL,NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmewritea32d8", vmewritea32d8, NULL, NULL);

  /* Single shot a24 access */

  Tcl_CreateObjCommand(pInterp, "sis3150::vmereada24d32", vmereada24d32, NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmewritea24d32", vmewritea24d32, 
		       NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmereada24d16", vmereada24d16, NULL,NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmewritea24d16", vmewritea24d16, NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmereada24d8", vmereada24d8, NULL,NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmewritea24d8", vmewritea24d8, NULL, NULL);

  /* Single shot a16 access */

  Tcl_CreateObjCommand(pInterp, "sis3150::vmereada16d32", vmereada16d32, NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmewritea16d32", vmewritea16d32, 
		       NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmereada16d16", vmereada16d16, NULL,NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmewritea16d16", vmewritea16d16, NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmereada16d8", vmereada16d8, NULL,NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmewritea16d8", vmewritea16d8, NULL, NULL);


  /* Block transfers:    */

  Tcl_CreateObjCommand(pInterp, "sis3150::vmedmareada32d32", vmedmareada32d32, 
		       NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmedmawritea32d32", vmedmawritea32d32,
		       NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmedmareada24d32", vmedmareada24d32, 
		       NULL, NULL);
  Tcl_CreateObjCommand(pInterp, "sis3150::vmedmawritea24d32", vmedmawritea24d32,
		       NULL, NULL);





  /* Export the commands so that scripts can namespace import them. */

  Tcl_GlobalEval(pInterp, "namespace eval sis3150 {namespace export *}");

  /* Return that all is ok with the world:                           */

  return TCL_OK;
  

}
