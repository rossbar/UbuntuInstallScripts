/* -*- c++ -*- */
/*
 * USRP - Universal Software Radio Peripheral
 *
 * Copyright (C) 2003,2004 Free Software Foundation, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

// This derived work loads SIS 3500 USB/VME controllers.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <usb.h>			/* needed for usb functions */
#include <getopt.h>
#include <assert.h>
#include <errno.h>

#include "usrp_prims.h"
#include "usrp_spi_defs.h"

const char* deviceRoot = "/proc/bus/usb"; // where the device specials live.

char *prog_name;


static void
set_progname (char *path)
{
  char *p = strrchr (path, '/');
  if (p != 0)
    prog_name = p+1;
  else
    prog_name = path;
}

static void
usage ()
{
  fprintf(stderr, "sisload device file\n");
  exit (1);
}

static void
die (const char *msg)
{
  fprintf (stderr, "%s (die): %s\n", prog_name, msg);
  exit (1);
}


static void
chk_result (bool ok)
{
  if (!ok){
    fprintf (stderr, "%s: failed\n", prog_name);
    exit (1);
  }
}

// Given a usb directory name and a device filename,
// construct the full path to the device.
// we are assuming that the output buffer is at least
// PATH_MAX+1 bytes long.
static void
full_device_name(char* fullname, const char* dir, const char* file)
{
  strcpy(fullname, deviceRoot);
  strcat(fullname, "/");
  strcat(fullname, dir);
  strcat(fullname , "/");
  strcat(fullname, file);


}

// Locate the USB device struct that matches a device special file.
// We do this by looking through the busses and devices on the
// bus, constructing the full filename of each device and comparing
// it to the one passed in.
// Returns NULL if not found, or a pointer to the device.
//
static struct usb_device*
locate_named_device(const char* theOne)
{
  struct usb_bus* bus =  usb_get_busses();
  while (bus) {
    struct usb_device* device = bus->devices;
    while (device) {
      char fullpath[PATH_MAX+1];
      full_device_name(fullpath, bus->dirname, device->filename);
      if(strcmp(fullpath, theOne) == 0) {
	return device;
      }
      device = device->next;
    }
    bus = bus->next;
  }
  return NULL;
}

// entry


int
main (int argc, char **argv)
{
  const char *device;
  const char *filename;
  
  set_progname (argv[0]);
  

  argc--; argv++;
  if(argc != 2) {
    usage();
    die("Missing parameters");
  }

  device   = argv[0];
  filename = argv[1];

  usrp_one_time_init ();

  // We loacate the USB device that matches the device special file
  // that was handed to us.

  struct usb_device *udev = locate_named_device(device);
  if(udev == 0) {
    fprintf(stderr, "Failed to find a USB device at device special %s\n", device);
    exit(1);
  }
  struct usb_dev_handle *udh = usrp_open_cmd_interface (udev);
  if (udh == 0){
    fprintf (stderr, "%s: failed to open_cmd_interface\n", prog_name);
    exit (1);
  }

  chk_result (usrp_load_firmware (udh, filename, true));

  if (udh){
    usrp_close_interface (udh);
    udh = 0;
  }

  return 0;
}
