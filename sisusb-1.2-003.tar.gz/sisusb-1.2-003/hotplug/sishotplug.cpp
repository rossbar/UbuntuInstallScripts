/*
    This software is Copyright by Ron Fox
    Copyright (c) 2005, all rights reserved.

    You may use this software under the terms of the GNU public license
    (GPL).  The terms of this license are described at:

     http://www.gnu.org/licenses/gpl.txt

     Author:
             Ron Fox
	     1918 Pinecrest Dr.
	     East Lansing, MI 48823
	     fox@kendo.msu.edu
*/

// This is the code for a usb permissions daemon.
// The program runs periodically looking for usb devices by a particular
// manufacturer (defaults to SIS).
// and sets the device special files for that device to world
// mode 0666, the purpose of this is to allow non-root users access to the
// device.
//   Firmware is loaded as specified by the --firmware switch.
//   The firmware load is done by assuming that the usb support program
//   fxload is installed and in /sbin.
//

// One wrinkle.  libusb will give us a directory and dev special filename
// relative to some base which for e.g. Debian is /proc/bus/usb
// For other distros of linux this may be something else.
// In addition, just for the heck of it, we may want to allow
// the software to work for other vendor's devices...since the world is full
// of usb these days... so the usage is:
//
//   sishotplug [--vendor=id] [--root=directoryroot] [--poll=seconds] \
//              [--debug]
//   Where:
//     -vendor=id specifies the USB Vendor id to look for (defaults to
//                0x16dc which is Wiener P&B.
//     -root=directoryroot specifies the path to the directory tree that
//                defines where the usb devices live. defaults to
//                /proc/bus/usb
//     --poll=seconds Defines how often this daemon runs. defaults to 5 seconds.
//     --debug   If present causes copious debugging output to be emitted to stdout.
//               note that if --debug is not present, the program
//               will fork off as a daemon.
//

// Headers

#include <usb.h>
#include <usrp_prims.h>
#include <string>
#include <sys/types.h>
#include <sys/stat.h>
#include <iostream>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include "cmdline.h"

using namespace std;

// Constants

const int    defaultId(0x1657);	           // Default vendor Id to look for.
const int   defaultProduct(0x3150);       // Default product id. 
const string defaultRoot("/proc/bus/usb"); // Default root of usb device tree.
const unsigned int defaultPolltime(5);     // Default polling interval.
const bool   defaultDebug(false);           // Default state of debugging. 

/*!
   load device firmware.

   \param special
      Path to the device special file.
   \param firmwareFile
      Path to the firmware file
 
   Note: We assume the GPL Program fxload is in /sbin/
         I decided not to allow it to be in path so that people can't
	 put in trojan fxload programs...as this software will run as root.
*/
void loadFirmware(struct usb_device* device, string firmwareFile, bool debug)
{
  if (debug) cerr << "About to load firmware\n";
  struct usb_dev_handle* udh = usrp_open_cmd_interface(device);
  if (udh == 0) {
    cerr << "hotplug unable to open USB handle on interface for firmware load\n";
    return;
  }
  sleep(1);

  if (!usrp_load_firmware(udh, firmwareFile.c_str(), true)) {
    cerr << "hotplug firmware load failed on interface\n";
  }
  usb_close(udh);

  if (debug)  cerr << "firmware load complete\n";
  
}

/*!
   setupDevice - set the mode on a device

   \param root
     root of usb dev special tree.
   \param bus
     Bus the device lives in.
   \param device
     Pointer to the usb_device structure for the device.
   \param firmwareFile
     path to file containing firmware.
*/
void setupDevice(string root, struct usb_bus* bus, struct usb_device* device,
		 string firmwareFile, bool debug)
{
  int status;

  // Compute the device special file in the /proc filesystem:

  string special = root;
  special += "/";
  special += bus->dirname;
  special += "/";
  special += device->filename;

  // If the device perms are already 0666, we don't need to 
  // setup the device... we'd rather not continuously load firmware
  // into the device if we can help it after all.. that would not
  // be conducive to efficient operations.

  struct stat info;
  status = stat(special.c_str(), &info);
  if (status < 0) {
    cerr << "Failed on stat for " << special <<  " : "  << strerror(errno) << endl;
    return;
  }
  if ((info.st_mode & 0777) == 0666) {
    if (debug) {
      cerr << special << " already initialized\n";
    }
    return;
  }
  
  
  if (debug) {
    cerr << "Setting mode of " << special << " to 0666" << endl;
  }

  status = chmod(special.c_str(), 0666);	// Probably should use symbolic perms...
  if (status < 0) {
    cerr << "Failed to chmod " << special << " : " << strerror(errno) << endl;
    return;
  }
  loadFirmware(device, firmwareFile, debug);
}


/*!
  Main loop
  \param id
     USB id we're looking for
  \param root
     Root of the USB device special file.
  \param polltime
     Number of seconds betwee polls.
  \param firmwareFile
      Name of file containing firmware.
  \param debug
     Enable debug.
*/   
void MainLoop(int id, string root, unsigned int polltime, string firmwareFile,
	      bool debug) 
{
  while (1) {
    if (debug) {cerr << "Starting a pass" << endl;}
    if (debug) {cerr << "Locating busses" << endl;}
    if (usb_find_busses() < 0) {
      cerr << "usb_find_busses failed " << strerror(errno) << endl;
    }
    if(usb_find_devices()) {
      cerr << "usb_find_devices failed: " << strerror(errno) << endl;
    }
    struct usb_bus* busses = usb_get_busses();
    while (busses) {
      if (debug) {cerr << "Enumerating devices on a bus" << endl;}
      struct usb_device* device = busses->devices;
      while(device) {
	int devId = device->descriptor.idVendor;
	if (debug) {
	  cerr << hex << "Device id = " << devId << " product: " 
	       << device->descriptor.idProduct 
	       << " matching for " << id 
	       << dec << endl;
	}
	if(devId == id) {
	  if (debug) {cerr << "Matched!" << endl;}
	  setupDevice(root, busses, device, firmwareFile, debug);
	} 
	else {
	  if (debug) {
	    cerr << "No match :-(" << endl;
	  }
	}

	device = device->next;
      }
      busses = busses->next;
    }
    cerr.flush();
    sleep(polltime);
  }
}

// Entry point (process commands).

int 
main(int argc, char** argv)
{
  usb_init();
  int          id(defaultId);
  int          product(defaultProduct);
  string       root(defaultRoot);
  unsigned int pollTime(defaultPolltime);
  bool         debug(defaultDebug);
  string       firmwareFile;

  struct gengetopt_args_info info;
  if (cmdline_parser(argc, argv, &info) < 0) {
    exit( -1);
  }

  if(info.vendor_given) {
    id = info.vendor_arg;
  }
  if(info.product_given) {
    product = info.product_arg;
  }
  if(info.root_given) {
    root = info.root_arg;
  }
  if(info.interval_given) {
    pollTime = info.interval_arg;
  }
  if(info.debug_given) {
    debug = info.debug_flag;
  }
  // Firmware is requried:
  
  firmwareFile = info.firmware_arg;

  if (debug) {
    cerr << "Running as follows: " << endl;
    cerr << "    vendor id: " << hex << id << dec << endl;
    cerr << "    product id:" << hex << product << dec << endl;
    cerr << "    Root dir:  " << root << endl;
    cerr << "    Poll time: " << pollTime << endl;
    cerr << "    debug:     " << (debug ? "on" : "off") << endl;
  }

  if(!debug) {
    daemon(0, 0);
  }
  MainLoop(id, root, pollTime, firmwareFile, debug);
}
