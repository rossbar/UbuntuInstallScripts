/***************************************************************************/
/*                                                                         */
/*  Filename: vme_A32BLT16_write.c                                         */
/*                                                                         */
/*  Funktion:                                                              */
/*                                                                         */
/*  Autor:                TH                                               */
/*  date:                 20.07.2010                                       */
/*  last modification:    20.07.2010                                       */
/*                                                                         */
/* ----------------------------------------------------------------------- */
/*                                                                         */
/*  SIS  Struck Innovative Systeme GmbH                                    */
/*                                                                         */
/*  Harksheider Str. 102A                                                  */
/*  22399 Hamburg                                                          */
/*                                                                         */
/*  Tel. +49 (0)40 60 87 305 0                                             */
/*  Fax  +49 (0)40 60 87 305 20                                            */
/*                                                                         */
/*  http://www.struck.de                                                   */
/*                                                                         */
/*  � 2010                                                                 */
/*                                                                         */
/***************************************************************************/

/*===========================================================================*/
/* Headers								     */
/*===========================================================================*/
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
    


#include <stdio.h>
#include <sis3150usb_vme.h>



/*===========================================================================*/
/* Globals					  			     */
/*===========================================================================*/



#define MAX_NUMBER_OF_PRINTS 0x10      
#define MAX_NUMBER_LWORDS 0x100000       /* 4MByte */

u_int32_t gl_wblt_data[MAX_NUMBER_LWORDS] ;
u_int16_t gl_uint16_wblt_data[MAX_NUMBER_LWORDS] ;



#define MAXIF 10

HANDLE m_device[MAXIF];
HANDLE gl_device;
//handling cmd line input	
	int numSlot=1;
	int numWrapSizeMode=9; // EVENT_CONF_PAGE_SIZE_256_WRAP
	int numSamples=256; // EVENT_CONF_PAGE_SIZE_256_WRAP
	int numEvents=10;
	int numPre = 64;

#ifdef not_used_here

int vme_A32DMA_D16_write(HANDLE  hXDev, u_int32_t vme_adr, u_int32_t* vme_data, 
                      u_int32_t req_num_of_words, u_int32_t* put_num_of_words);

int vme_A32BLT16_write(HANDLE  hXDev, u_int32_t vme_adr, u_int32_t* vme_data, 
                      u_int32_t req_num_of_words, u_int32_t* put_num_of_words);
#endif

/*===========================================================================*/
/* Main      					  	                     */
/*===========================================================================*/
int main(int argc, char* argv[]) 
{
struct SIS3150USB_Device_Struct info[MAXIF];
unsigned int mod_base;
unsigned int no_of_16bit_words, put_num_of_words;
unsigned int start_data_value;
unsigned int i;
unsigned int* unit32_ptr;

int return_code ;
u_int32_t data, addr ;
     int status;
    int intf;
    unsigned int found;

if (argc<3)
  {
  fprintf(stderr, "usage: %s VME_BASE_ADDR  NO_OF_16bit-WORDS  START_DATA_VALUE   \n", argv[0]);
  return 1;
  }
 
mod_base           = strtoul(argv[1],NULL,0) ;
no_of_16bit_words  = strtoul(argv[2],NULL,0) ;
start_data_value   = strtoul(argv[3],NULL,0) ;
 
#ifdef raus
 #endif
 
/***********************************************************************************************/
/***********************************************************************************************/
/********************                                                     **********************/
/********************                                                     **********************/
/********************                                                     **********************/
/********************    SIS3150USB setup                                    **********************/
/********************                                                     **********************/
/********************                                                     **********************/
/********************                                                     **********************/
/***********************************************************************************************/
/***********************************************************************************************/
    status = FindAll_SIS3150USB_Devices (info, &found, MAXIF);
    printf("\n ***** found: %d interface(s) ** ",found);
 
    if (found==0) {
       printf("\nno device found, exiting\n\n");
       return -1;
    }

  
   for (intf=0;intf<found;intf++) {
	printf("bus: %s ** ",(PCHAR)info[intf].cDName);
	printf("serial number: %d \n ",info[intf].idSerNo);
        status = Sis3150usb_OpenDriver_And_Download_FX2_Setup((PCHAR)info[intf].cDName, 
                                                                  &m_device[intf]);
        printf("** Interface: %d handle: %x ** ",intf,m_device[intf]);
        sis3150Usb_Register_Single_Read(m_device[intf], 0x1, (ULONG*)&data) ;
        printf("SIS3150USB Version: 0x%08x\n\n",data);

    }       


// use 1. USB device
	gl_device=m_device[0];


  /* test pattern (increment ) */
   //for (i=0; i<no_of_16bit_words; i++)   gl_wblt_data[i] = start_data_value + i ;
   for (i=0; i<no_of_16bit_words; i++)   gl_uint16_wblt_data[i] = start_data_value + i ;
   unit32_ptr = (unsigned int*) gl_uint16_wblt_data ;
  
   do {
	addr=mod_base    ;
	return_code = vme_A32BLT16_write(gl_device, addr,  unit32_ptr, no_of_16bit_words, &put_num_of_words ) ;
	//return_code = vme_A32DMA_D16_write(gl_device, addr,  unit32_ptr, no_of_16bit_words, &put_num_of_words ) ;
	if (return_code != 0) {printf("vme_A32BLT16_write:ret_code=0x%08x at addr=0x%08x\n",return_code,addr);return -1;}
	printf("\n\nput_num_of_words=  0x%08x    \n", put_num_of_words);   
 
  } while (1) ;

/******************************************************************/
/*                                                                */
/*                                                                */
/*                                                                */
/******************************************************************/

	

	return 0;
}

/* end main */




#ifdef not_used_here
int vme_A32DMA_D16_write(HANDLE  hXDev, u_int32_t vme_adr, u_int32_t* vme_data, 
                      u_int32_t req_num_of_words, u_int32_t* put_num_of_words)
{
  int return_code ;
 //  printf(" :  sizeof(ULONG) = 0x%08x\n", sizeof(ULONG) );
 
  return_code = sis3150Usb_Vme_Dma_Write(hXDev, vme_adr, 0x9/*am*/, 2 /*size*/, 0,
					     //  (ULONG*)vme_data, req_num_of_words, (ULONG*)put_num_of_words ) ;
					      (unsigned int*) vme_data, req_num_of_words, (ULONG*)put_num_of_words ) ;


 
					      
  return (return_code) ;
}



int vme_A32BLT16_write(HANDLE  hXDev, u_int32_t vme_adr, u_int32_t* vme_data, 
                      u_int32_t req_num_of_words, u_int32_t* put_num_of_words)
{
  int return_code ;
 //  printf(" :  sizeof(ULONG) = 0x%08x\n", sizeof(ULONG) );
 
  return_code = sis3150Usb_Vme_Dma_Write(hXDev, vme_adr, 0xb/*am*/, 2 /*size*/, 0,
					     //  (ULONG*)vme_data, req_num_of_words, (ULONG*)put_num_of_words ) ;
					      (unsigned int*) vme_data, req_num_of_words, (ULONG*)put_num_of_words ) ;


 
					      
  return (return_code) ;
}

#endif




/***************************************************************************************************************/




